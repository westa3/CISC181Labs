package pkgCore;

import java.io.BufferedReader;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Dictionary {

	private ArrayList<Word> words = new ArrayList<Word>();

	public Dictionary() {
		LoadDictionary();
	}

	public ArrayList<Word> getWords() {
		return words;
	}

	private void LoadDictionary() {
		InputStream is = getClass().getClassLoader().getResourceAsStream("util/words.txt");
		try (BufferedReader reader = new BufferedReader (new InputStreamReader(is))) {
			while (reader.ready()) {
				String line = reader.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Word findWord(String strWord) {
		Word w = new Word(strWord);
		int idx = Collections.binarySearch(words, w);
		if (idx < 0) {
			return null;
		}
		else {
			return words.get(idx);
		}
	}
}

