package pkgCore;

import java.util.UUID;

public class Word implements Comparable<Word> {

	private UUID WordID;
	private String Word;

	public Word (String word)
	{
		this.WordID = UUID.randomUUID();
		this.Word = word;
		
	}
	@Override
	public boolean equals(Object obj) {
		Word w = (Word) obj;
		if (w.getWord().toUpperCase().equalsIgnoreCase(this.getWord().toUpperCase())) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int compareTo(Word o) {
		Word w = (Word) o;
		if ((w.getWord().compareToIgnoreCase(this.getWord()) < 0) || (w.getWord().compareToIgnoreCase(this.getWord())) > 0) {
			return 1;
		} 
		else {
			return 0;
		}
	}
	public String getWord() {
		return Word;
	}
	public UUID getWordID() {
		return WordID;
	}

}
